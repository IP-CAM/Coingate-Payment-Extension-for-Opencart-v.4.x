<?php

namespace CoinGate\Exception;

class InvalidArgumentException extends \InvalidArgumentException
{
}
