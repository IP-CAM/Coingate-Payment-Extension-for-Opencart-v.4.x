<?php
$_['text_title']      = 'Bitcoin & Altcoins (CoinGate)';
$_['button_confirm']  = 'Pay with Bitcoin or Altcoins';